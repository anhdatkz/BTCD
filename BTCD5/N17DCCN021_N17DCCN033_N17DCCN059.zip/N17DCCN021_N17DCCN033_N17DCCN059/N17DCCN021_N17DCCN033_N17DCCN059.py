# BÀI TẬP CHUYÊN ĐỀ 5
# Sinh viên thực hiện:
# MSV: N17DCCN021 - HỌ TÊN: NGUYỄN ANH DŨNG
# MSV: N17DCCN033 - HỌ TÊN: LÊ PHƯỚC ANH ĐẠT
# MSV: N17DCCN059 - HỌ TÊN: TRỊNH ĐỨC HUY
import re
import numpy as np
import nltk
from nltk.corpus import stopwords

nltk.download('punkt')
nltk.download('stopwords')

# Tải stop words
stop_words = set(stopwords.words('english'))


# Loại bỏ stop words
def remove_stopwords(documents):
    filtered_documents = []
    for doc in documents:
        words = nltk.word_tokenize(doc)
        filtered_words = [word for word in words if word.lower() not in stop_words]
        filtered_documents.append(' '.join(filtered_words))
    return filtered_documents

######### GIAI ĐOẠN 1: CHUẨN HÓA INPUT #########
# Mục tiêu: Xóa bỏ kí tự khoảng trắng thừa, kí tự đặc biệt, số,
# Biến đổi lowercase
def read_file_and_modify(filename):
    with open('./doc-text', 'r') as f:
        text = f.read()
    clean_text = ""
    for char in text:
        if char not in "\n":
            clean_text += char
    text = text.strip()  # loại bỏ khoảng trắng thừa ở đầu và cuối văn bản
    words = text.split()  # tách văn bản thành các từ và loại bỏ khoảng trắng thừa giữa
    # các từ
    words = " ".join(words)
    clean_text = re.sub(r'\d+', '', words)  # loại bỏ số

    # loại bỏ khoảng trắng thừa ở đầu và cuối câu
    # Tách từng văn bản thành list
    clean_text = clean_text.split("/")
    for i in range(len(clean_text)):
        clean_text[i] = clean_text[i].strip().lower()
    return clean_text


######### GIAI ĐOẠN 2: CHUẨN HÓA DỮ LIỆU #########
docs = read_file_and_modify("doc-text")
docs = remove_stopwords(docs)
docs = docs[:-1]
#========================================================================================

# Tạo danh sách tất cả các thuật ngữ duy nhất trong tài liệu
all_terms = set()
for doc in docs:
    terms = re.findall(r'\b\w+\b', doc.lower())
    all_terms.update(set(terms))

# Tạo các vectơ nhị phân cho mỗi tài liệu
binary_vectors = []
for doc in docs:
    terms = re.findall(r'\b\w+\b', doc.lower())
    binary_vector = [1 if term in terms else 0 for term in all_terms]
    binary_vectors.append(binary_vector)

# Câu truy vấn
query = "NUMBER REPRESENTATION IN BINARY MACHINES"

# Tạo một vectơ nhị phân cho truy vấn
query_terms = re.findall(r'\b\w+\b', query.lower())
query_vector = np.array([1 if term in query_terms else 0 for term in all_terms])

# Tính toán sự giống nhau giữa vectơ truy vấn và vectơ nhị phân của mỗi tài liệu
similarities = np.dot(binary_vectors, query_vector) / np.sqrt(np.sum(binary_vectors, axis=1) * np.sum(query_vector ** 2))
ranking = np.argsort(similarities)[::-1][:5]  # Only retrieve the top 5 results

# In các tài liệu được xếp hạng
for rank, index in enumerate(ranking):
    print(f"Rank {rank+1}: Document {index+1} ({similarities[index]:.3f})")
